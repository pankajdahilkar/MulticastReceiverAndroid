#include "devicemodel.h"



DeviceModel::DeviceModel(QObject *parent ) : QAbstractListModel(parent)
{
    m_devices.append({ "Radio 1", "115200", "8" , "1","N","*","#","5","@","1" });

}

int DeviceModel::rowCount(const QModelIndex &) const
{
    return m_devices.count();
}

QVariant DeviceModel::data(const QModelIndex &index, int role) const
{
    if (index.row() < rowCount())
        switch (role) {
        case devicenameRole: return m_devices.at(index.row()).devicename;
        case baudrateRole: return m_devices.at(index.row()).baudrate;
        case databitRole: return m_devices.at(index.row()).databit;
        case stopbitsRole: return m_devices.at(index.row()).stopbits;
        case  parityRole: return m_devices.at(index.row()).parity;
        case header1Role: return m_devices.at(index.row()).header1;
        case header2Role: return m_devices.at(index.row()).header2;
        case lengthRole: return m_devices.at(index.row()).length;
        case footerRole: return m_devices.at(index.row()).footer;
        case checksumRole: return m_devices.at(index.row()).checksum;
        default: return QVariant();
    }
    return QVariant();
}

QHash<int, QByteArray> DeviceModel::roleNames() const
{
    static const QHash<int, QByteArray> roles {
        { devicenameRole, "devicename" },
        { baudrateRole, "baudrate" },
        { databitRole, "databit" },
        {parityRole,"parity"},
        { stopbitsRole, "stopbit" },
        {header1Role,"header1"},
        {header2Role,"header2"},
        {lengthRole,"length"},
        {footerRole,"footer"},
        {checksumRole,"checksum"}
    };
    return roles;
}

QVariantMap DeviceModel::get(int row) const
{
    const Device device = m_devices.value(row);
    return { {"baudrate", device.baudrate}, {"devicename", device.devicename}, {"databit", device.databit}, {"parity", device.parity},
        {"stopbit",device.stopbits},{"header1",device.header1},{"header2",device.header2},{"length",device.length},{"footer",device.footer},
        {"checsum",device.checksum}};
}

void DeviceModel::append(const QString &devicename, const QString &baudrate, const QString  &databit, const QString &parity,const QString &stopbits,
                         const QString &header1, const QString  &header2, const QString &length,const QString  &footer, const QString &checksum)
{
    int row = 0;
    while (row < m_devices.count() && devicename > m_devices.at(row).devicename)
        ++row;
    beginInsertRows(QModelIndex(), row, row);
    m_devices.insert(row, {devicename, baudrate, databit, parity,stopbits,header1,header2,length,footer,checksum});
    endInsertRows();
}

void DeviceModel::set(int row,const QString &devicename, const QString &baudrate, const QString  &databit, const QString &parity,const QString &stopbits,
                      const QString &header1, const QString  &header2, const QString &length,const QString  &footer, const QString &checksum)
{
    if (row < 0 || row >= m_devices.count())
        return;

    m_devices.replace(row, {devicename, baudrate, databit, parity,stopbits,header1,header2,length,footer,checksum});
    dataChanged(index(row, 0), index(row, 0), { devicenameRole, baudrateRole, databitRole, parityRole,stopbitsRole,header1Role,header2Role,lengthRole,footerRole,checksumRole });
}

void DeviceModel::remove(int row)
{
    if (row < 0 || row >= m_devices.count())
        return;

    beginRemoveRows(QModelIndex(), row, row);
    m_devices.removeAt(row);
    endRemoveRows();
}
