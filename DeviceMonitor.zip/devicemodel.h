#ifndef DEVICEMODEL_H
#define DEVICEMODEL_H


#include <QAbstractListModel>

class DeviceModel : public QAbstractListModel
{
    Q_OBJECT

public:
    enum DeviceRole {
        devicenameRole = Qt::DisplayRole,
        baudrateRole = Qt::UserRole,
        databitRole,
        parityRole,
        stopbitsRole,
        header1Role,
        header2Role,
        lengthRole,
        footerRole,
        checksumRole
    };
    Q_ENUM(DeviceRole)

    DeviceModel(QObject *parent = nullptr);

    int rowCount(const QModelIndex & = QModelIndex()) const;
    QVariant data(const QModelIndex &index, int role = Qt::DisplayRole) const;
    QHash<int, QByteArray> roleNames() const;

    Q_INVOKABLE QVariantMap get(int row) const;
    Q_INVOKABLE void append(const QString &devicename, const QString &baudrate, const QString  &databit, const QString &parity,const QString &stopbits,
                            const QString &header1, const QString  &header2, const QString &length,const QString  &footer, const QString &checksum);

    Q_INVOKABLE void set(int row, const QString &devicename, const QString &baudrate, const QString  &databit, const QString &parity,const QString &stopbits,
                         const QString &header1, const QString  &header2, const QString &length,const QString  &footer, const QString &checksum);
    Q_INVOKABLE void remove(int row);

private:
    struct Device {
        QString devicename;
        QString baudrate;
        QString databit;
        QString parity;
        QString stopbits;
        QString header1;
        QString header2;
        QString length;
        QString footer ;
        QString checksum;
    };

    QList<Device> m_devices;
};


#endif // DEVICEMODEL_H
